<?php 
if (isset($_POST["submit"])) {
	$namafile = basename($_FILES['fileToUpload']['name']);
	$namasementara = $_FILES['fileToUpload']['tmp_name'];
	$dirupload = "uploads/";
	$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
	if ($check !== false) {

		$fullpath = $dirupload.$namafile;
		$terupload = move_uploaded_file($namasementara,$fullpath);
		$imageFiletype = pathinfo($fullpath,PATHINFO_EXTENSION);

		if ($terupload) {
			echo "upload berhasil</br>";
			echo "Link: <a href='",$dirupload.$namafile."'>".$namafile."</a>";
		}else{
			echo "upload gagal";
		}

			echo "File is an image =" . $check["mime"] . ",";
			echo "<img src='$fullpath' alt='SMK Bisa'>";
		} else {
			echo "file is not an image";
		}

}
?>