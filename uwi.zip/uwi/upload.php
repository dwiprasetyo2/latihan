<?php
$namafile = basename($_FILES['fileToUpload']['name']);
$filesementara= $_FILES['fileToUpload']['tmp_name'];
$target_dir = "uploads/";
print_r($_FILES);
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
if(isset($_POST["submit"])) {
$check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
if($check !== false) {

	$fullpath=$dirupload.$namazafile;
	$terupload=move_uploaded_file($filesementara,$fullpath);
	$imageFileType=pathinfo($fullpath,PATHINFO_EXTENSION);
	if ($terupload) {
		echo "Upload berhasil<br/>";
		echo "link: <a href=".$dirupload.$namafile."'>".$namafile."</a>";
		}else{
			echo "Upload gagal";
		}
			echo "File is an image - " . $check["mime"] . ".";
			echo "<img src='$fullpath' alt='smk bisa'>";
		}else{
			echo "file is not an image.";
		}
		$uploadOk = 1;
		} else {
		echo "File is not an image.";
		$uploadOk = 0;
		}
?>